import { Component } from '@angular/core';
import { UserInfoService } from '../user-info.service';
import { ActivatedRoute } from '@angular/router';
interface productSchema {
  id: number,
  title: string
}
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {
  productsList: Array<productSchema> | undefined;
  constructor(
    private activatedRoute: ActivatedRoute,
    private userInfo: UserInfoService) {
      this.productsList=userInfo.productsList;
  }
  addToCart(id:number){
    this.userInfo.addProductsToCart(id);
  }
}
