import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserInfoService } from '../user-info.service';
@Component({
  selector: 'app-edit-user-info',
  templateUrl: './edit-user-info.component.html',
  styleUrls: ['./edit-user-info.component.css']
})
export class EditUserInfoComponent {
  editUserInfo:FormGroup;
  parameterId:number|undefined;
  constructor(private activatedRoute:ActivatedRoute,private userServices:UserInfoService,public router:Router){
    this.editUserInfo=new FormGroup({
      name:new FormControl(''),
      email:new FormControl(''),
      password:new FormControl('')
    })
    this.activatedRoute.params.subscribe(p=>{
      this.parameterId=p['userId']
    })
  }
  editUser(){
    // console.log(this.parameterId);
    this.userServices.editUsers(this.parameterId!,this.editUserInfo.value.name,this.editUserInfo.value.email,this.editUserInfo.value.password);
    // this.router.navigate(['/users']);
  }
}
