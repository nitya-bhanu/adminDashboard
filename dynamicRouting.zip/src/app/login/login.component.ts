import { Component } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { UserInfoService } from '../user-info.service';
import { Route, Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  signInForm:FormGroup;
  constructor(private userInfo:UserInfoService,private router:Router){
    this.signInForm=new FormGroup({
      email:new FormControl('', [
        Validators.required,
        Validators.email,
        Validators.pattern("[^@ \t\r\n]+@[^@ \t\r\n]+\.[^@ \t\r\n]+"),
      ]),
      password:new FormControl('', [
        Validators.required,
        Validators.minLength(5),
        Validators.pattern("^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$"),
      ])
    })
  }
  checkValidation(){
    let x=false;
    if (this.signInForm.invalid) {
      // this.newUserInfo.markAllAsTouched();
      alert('password must be atleast 5 characters long and must contain 1 letter, 1 alphabet, email id must contain . and @ symbol');
      return;
    }
    for(let i=0;i<this.userInfo.usersList.length;i++){
      if(this.userInfo.usersList[i].email===this.signInForm.value.email)
      {
        x=true;
        if(this.userInfo.usersList[i].password===this.signInForm.value.password){
          alert('Sign in Successful')
          this.router.navigate(['/users']);
        }
        else
        alert('enter valid info');
      }
    }
    if(!x)
    alert('Enter valid email Id');
  }
}
