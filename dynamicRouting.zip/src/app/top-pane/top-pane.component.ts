import { Component } from '@angular/core';

@Component({
  selector: 'app-top-pane',
  templateUrl: './top-pane.component.html',
  styleUrls: ['./top-pane.component.css']
})
export class TopPaneComponent {

}
