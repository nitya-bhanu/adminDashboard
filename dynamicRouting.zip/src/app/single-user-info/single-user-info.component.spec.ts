// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { SingleUserInfoComponent } from './single-user-info.component';

// describe('SingleUserInfoComponent', () => {
//   let component: SingleUserInfoComponent;
//   let fixture: ComponentFixture<SingleUserInfoComponent>;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       declarations: [SingleUserInfoComponent]
//     });
//     fixture = TestBed.createComponent(SingleUserInfoComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
