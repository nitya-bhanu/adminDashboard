// import { Component } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';
// import { UserInfoService } from '../user-info.service';
// interface userSchema{
//   id:number,
//   name:string,
//   personalInfo:
//     {
//       age:number,
//       pob:string
//     }
// }
// @Component({
//   selector: 'app-single-user-info',
//   templateUrl: './single-user-info.component.html',
//   styleUrls: ['./single-user-info.component.css']
// })
// export class SingleUserInfoComponent {
//   userInfo:userSchema|undefined;
//   constructor(private activatedRoute:ActivatedRoute, private userInfoList:UserInfoService){
//     // let userId:number=this.e1.snapshot.params['userId'];
//     this.activatedRoute.params.subscribe(params=>{
//       console.log(params);
//       this.userInfo=this.userInfoList.usersList.find(e=>{
//       return params['userId']==e.id;
//     })
//     })
//     console.log(this.userInfo);
//   }
// }
