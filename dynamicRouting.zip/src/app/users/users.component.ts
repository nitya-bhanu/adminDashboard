import { Component } from '@angular/core';
import { UserInfoService } from '../user-info.service';
import { ActivatedRoute } from '@angular/router';
interface userSchema{
  id?:number,
  name:string,
  email:string,
  password:string
}
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {
  userInfoList:Array<userSchema>|undefined;
  constructor(private e:UserInfoService, private e1:ActivatedRoute){
    this.userInfoList=e.usersList;
  }
  editUser(e:number){
    console.log(this.userInfoList);
  }
  deleteUser(e:number){
    console.log(this.userInfoList?.filter(x=> {return x.id===e}));
    this.userInfoList=this.e.deleteUsers(e);
  }
}
