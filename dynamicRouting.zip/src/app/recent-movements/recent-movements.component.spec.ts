import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecentMovementsComponent } from './recent-movements.component';

describe('RecentMovementsComponent', () => {
  let component: RecentMovementsComponent;
  let fixture: ComponentFixture<RecentMovementsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RecentMovementsComponent]
    });
    fixture = TestBed.createComponent(RecentMovementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
