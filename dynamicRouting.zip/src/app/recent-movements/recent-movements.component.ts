import { Component } from '@angular/core';

@Component({
  selector: 'app-recent-movements',
  templateUrl: './recent-movements.component.html',
  styleUrls: ['./recent-movements.component.css']
})
export class RecentMovementsComponent {

}
