import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { MarketComponent } from './market/market.component';
import { CartComponent } from './cart/cart.component';
import { UsersComponent } from './users/users.component';
import { ProductsComponent } from './products/products.component';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { TopPaneComponent } from './top-pane/top-pane.component';
import { PriceCardComponent } from './price-card/price-card.component';
import { LatestProjectsComponent } from './latest-projects/latest-projects.component';
import { RecentMovementsComponent } from './recent-movements/recent-movements.component';
import { FooterComponent } from './footer/footer.component';
import { ChartsComponent } from './charts/charts.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgChartsModule } from 'ng2-charts';
import { SomethingComponent } from './something/something.component';
import { EditUserInfoComponent } from './edit-user-info/edit-user-info.component';
@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LoginComponent,
    RegisterComponent,
    MarketComponent,
    CartComponent,
    UsersComponent,
    ProductsComponent,
    HomeComponent,
    NavbarComponent,
    TopPaneComponent,
    PriceCardComponent,
    LatestProjectsComponent,
    RecentMovementsComponent,
    FooterComponent,
    ChartsComponent,
    SomethingComponent,
    EditUserInfoComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgChartsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
