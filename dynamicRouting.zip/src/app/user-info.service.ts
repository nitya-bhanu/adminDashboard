import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
interface productSchema {
  id: number,
  title: string
}
interface userSchema {
  id: number,
  name: string,
  email: string,
  password: string
}
interface userFormData {
  id?: number,
  name: string,
  email: string,
  password: string
}
@Injectable({
  providedIn: 'root'
})

export class UserInfoService {
  productsList = [
    {
      id: 1,
      title: "prod1"
    },
    {
      id: 2,
      title: "prod2"
    },
    {
      id: 3,
      title: "prod3"
    },
    {
      id: 4,
      title: "prod4"
    }
  ];
  cartProducts:Array<number>=[];
  usersList: Array<userSchema> = [
    {
      id: 1,
      name: "user1",
      email: "xyz@gmail.com",
      password: "test@89"
    }
  ];
  constructor(private router:Router) { }
  addProducts(e: productSchema) {
    this.productsList.push(e);
  }
  addUsers(e: userFormData) {
    let x = {
      id: this.usersList.length + 1,
      name: e.name,
      email: e.email,
      password: e.password
    }
    if (x) {
      console.log(x);
      this.usersList.push(x);
    }
    else
      console.log('failed');
  }
  deleteUsers(e: number) {
    this.usersList = this.usersList.filter(x => { return x.id != e });
    return this.usersList;
  }
  editUsers(id: number, name: string, email: string, password: string) {
    for (let i = 0; i < this.usersList.length; i++) {
      if (this.usersList[i].id == id) {
        console.log("Id matched before: ",this.usersList[i]);
        
        this.usersList[i].email = email;
        this.usersList[i].password = password;
        this.usersList[i].name = name;

        console.log("Id matched after: ",this.usersList[i]);
        break;
      }
    }
    this.router.navigate(['/users']);
  }
  addProductsToCart(id:number){
    this.cartProducts.push(id);
  }
}
