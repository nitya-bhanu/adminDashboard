import { Component } from '@angular/core';
import { UserInfoService } from '../user-info.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  newUserInfo:FormGroup;
  constructor(private userInfo:UserInfoService,public router:Router){
    this.newUserInfo=new FormGroup({
      name:new FormControl('',[
        Validators.required,
      ]),
      email:new FormControl('', [
        Validators.required,
        Validators.email,
        Validators.pattern("[^@ \t\r\n]+@[^@ \t\r\n]+\.[^@ \t\r\n]+"),
      ]),
      password:new FormControl('', [
        Validators.required,
        Validators.minLength(5),
        Validators.pattern("^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$"),
      ])
    });
  }
  addUsers(){
    console.log(this.newUserInfo.value)
    if (this.newUserInfo.invalid) {
      // this.newUserInfo.markAllAsTouched();
      alert('password must be atleast 5 characters long and must contain 1 letter, 1 alphabet, email id must contain . and @ symbol');
      return;
    }
    this.userInfo.addUsers(this.newUserInfo.value);
    this.router.navigate(['/users']);
  }
}
