import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { MarketComponent } from './market/market.component';
import { ProductsComponent } from './products/products.component';
import { RegisterComponent } from './register/register.component';
import { UsersComponent } from './users/users.component';
import { CartComponent } from './cart/cart.component';
import { NgChartsModule } from 'ng2-charts';
import { EditUserInfoComponent } from './edit-user-info/edit-user-info.component';
const routes: Routes = [
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "dashboard",
    component: DashboardComponent
  },
  {
    path: "market",
    component: MarketComponent
  },
  {
    path: "products",
    component: ProductsComponent
  },
  {
    path: "cart",
    component: CartComponent
  },
  {
    path: "users",
    component: UsersComponent,
    children: [
      {
        path: 'edit-user-info/:userId',
        component: EditUserInfoComponent
      }
    ]
  },
  {
    path:"login",
    component:LoginComponent
  },
  {
    path: "register",
    component: RegisterComponent
  },
  {
    path:"products",
    component:ProductsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes),
    NgChartsModule,
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
